public class lion extends Animal {

    private int loudness;

    public lion(String code,String name,String anclass,float weight,int age,int loudness) {
        super(code, name, anclass, weight, age);
        this.loudness=loudness;
    }


    public int getloudness() {
        return loudness;
    }

    public void setloudness(int loudness) {
        this.loudness = loudness;
    }

    public void LoudLion(){
        if (loudness>50){
            System.out.println("This is a loud lion");
        }
        if (loudness<=50) {
            System.out.println("This is a quiet lion");
        }
    }

}
