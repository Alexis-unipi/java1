public class hipo extends Animal {

    private float energy;

    public hipo(String code,String name,String anclass,float weight,int age,int energy) {
        super(code, name, anclass, weight, age);
        this.energy=energy;
    }


    public float getenergy() {
        return energy;
    }

    public void setenergy(int energy) {
        this.energy = energy;
    }

    public void EnHipo(){
        if (energy>50){
            System.out.println("This is an energetic hipo");
        }
        if (energy<=50) {
            System.out.println("This is a tired hipo");
        }
    }
}
