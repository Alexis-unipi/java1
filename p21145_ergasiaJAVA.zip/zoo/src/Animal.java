import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public abstract class Animal  {

    private String code;
    private String name;
    private String anclass;
    private float weight;

    private int age;


    static ArrayList<Animal> AnimalArrayList =new ArrayList<>();
    public Animal(String code,String name,String anclass,float weight,int age) {
        this.code=code;
        this.name=name;
        this.anclass=anclass;
        this.weight=weight;
        this.age=age;
    }

    public String getCode() {
        return code;
    }



    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
       this.name = name;
    }

    public String getAnclass() {
        return anclass;
    }

    public void setAnclass(String anclass) {
        this.anclass = anclass;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public float getAge() {
        return age;
    }

    public void setAvage(int avage) {
        this.age = avage;
    }


    @Override
    public String toString() {
        return "Animal{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", anclass='" + anclass + '\'' +
                ", weight=" + weight +
                ", age=" + age +
                '}';
    }
    public static void serialize(){
        try
        {
            FileOutputStream fos = new FileOutputStream("listData");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(AnimalArrayList);
            oos.close();
            fos.close();
        }
        catch (IOException ioe)
        {
            ioe.printStackTrace();
        }
    }



}
