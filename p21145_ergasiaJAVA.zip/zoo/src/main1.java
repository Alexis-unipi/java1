
import java.util.Objects;
import java.util.Scanner;


public class main1  {
    public static void main(String[]args){
        boolean flag=false;
        while(!flag) {

            int lions = 0;
            int hipos = 0;
            int gorilas = 0;
            System.out.println("Choose from these choices");
            System.out.println("-------------------------\n");
            System.out.println("1 - Show available animals");
            System.out.println("2 - Add a new animal");
            System.out.println("3 - Search animal by name");
            System.out.println("4 - Search animal with password");
            System.out.println("5 - Edit animal ");
            System.out.println("6 - Remove animal");
            System.out.println("7 - Exit");




            int selection;
            Scanner keyboard = new Scanner(System.in);
            selection = keyboard.nextInt();

            if (selection == 1) {
                System.out.println(Animal.AnimalArrayList);


            }

            if (selection == 2) {
                String code;
                String anclass;
                String name;
                int age;
                float weight;
                System.out.println("Choose an animal to add to the zoo");
                System.out.println("-------------------------\n");
                System.out.println("1 - Lion");
                System.out.println("2 - Hipopotamus");
                System.out.println("3 - Gorila");

                int choice;
                choice = keyboard.nextInt();

                if (choice == 1) {
                    lions = lions + 1;
                    code = "li" + lions;
                    int loud;
                    System.out.println("Enter lion 's name: ");
                    name = keyboard.next();
                    System.out.println("Enter lion 's age: ");
                    age = keyboard.nextInt();
                    System.out.println("Enter lion 's weight: ");
                    weight = keyboard.nextFloat();
                    System.out.println("Enter lion 's loudness: ");
                    loud = keyboard.nextInt();
                    System.out.println("Enter animal 's class: ");
                    anclass = keyboard.next();



                    lion l1 = new lion(code, name, anclass, weight, age, loud);
                    Animal.AnimalArrayList.add(l1);
                    l1.LoudLion();

                }

                if (choice == 2) {
                    hipos = hipos + 1;
                    code = "hi" + hipos;
                    int energy;
                    System.out.println("Enter hipo 's name: ");
                    name = keyboard.next();
                    System.out.println("Enter hipo 's age: ");
                    age = keyboard.nextInt();
                    System.out.println("Enter hipo 's weight: ");
                    weight = keyboard.nextFloat();
                    System.out.println("Enter hipo 's class: ");
                    anclass = keyboard.next();
                    System.out.println("Enter hipo 's energy: ");
                    energy = keyboard.nextInt();


                    hipo h1 = new hipo(code, name, anclass, weight, age,energy);
                    Animal.AnimalArrayList.add(h1);
                    h1.EnHipo();

                }
                if (choice == 3) {
                    gorilas = gorilas + 1;
                    code = "go" + gorilas;
                    int strength;
                    System.out.println("Enter gorila 's name: ");
                    name = keyboard.next();
                    System.out.println("Enter gorila 's age: ");
                    age = keyboard.nextInt();
                    System.out.println("Enter gorila 's weight: ");
                    weight = keyboard.nextFloat();
                    System.out.println("Enter gorila 's strength: ");
                    strength = keyboard.nextInt();
                    System.out.println("Enter gorila 's class: ");
                    anclass = keyboard.next();



                    gorila g1 = new gorila(code, name, anclass, weight, age, strength);
                    Animal.AnimalArrayList.add(g1);
                    g1.StrongGorila();
                }
            }

            if (selection == 3) {
                String uname;
                System.out.println("Enter name: ");
                uname = keyboard.next();

                for (Animal an : Animal.AnimalArrayList){
                    if (an.getName().contains(uname)){
                        System.out.println("There is an animal in this zoo with that name:");
                        System.out.println(an);
                    }
                }



            }






            if (selection == 4) {
                String ucode;




                System.out.println("Enter code: ");
                ucode = keyboard.next();
                for (Animal an : Animal.AnimalArrayList) {
                    if (Objects.equals(ucode, an.getCode())) {
                        System.out.println("There is an animal in this zoo with that code:");
                        System.out.println(an);


                    }
                }


            }

            if (selection == 5) {
                String ucode;
                System.out.println("Choose ");
                System.out.println("-------------------------\n");
                System.out.println("1 - Lion");
                System.out.println("2 - Hipopotamus");
                System.out.println("3 - Gorila");
                int choice;
                choice=keyboard.nextInt();
                if(choice==1){
                    System.out.println("Enter the code of the animal you want to edit: ");
                    ucode = keyboard.next();
                    String code;
                    String anclass;
                    String name;
                    int age;
                    float weight;
                    int loud;
                    int counter=0;
                    for (Animal lion : Animal.AnimalArrayList) {
                        if (Objects.equals(ucode, lion.getCode())) {
                            System.out.println("Enter lion 's name: ");
                            name = keyboard.next();
                            System.out.println("Enter lion 's code: ");
                            code = keyboard.next();
                            System.out.println("Enter lion 's age: ");
                            age = keyboard.nextInt();
                            System.out.println("Enter lion 's weight: ");
                            weight = keyboard.nextFloat();
                            System.out.println("Enter lion 's loudness: ");
                            loud = keyboard.nextInt();
                            System.out.println("Enter lion 's class: ");
                            anclass = keyboard.next();
                            lion l1 = new lion(code, name, anclass, weight, age, loud);
                            Animal.AnimalArrayList.set(counter,l1);
                            l1.LoudLion();

                        }
                        counter=counter+1;


                    }

                }
                if(choice==2){
                    System.out.println("Enter the code of the animal you want to edit: ");
                    ucode = keyboard.next();
                    String code;
                    String anclass;
                    String name;
                    int age;
                    float weight;
                    int energy;
                    int counter=0;
                    for (Animal lion : Animal.AnimalArrayList) {
                        if (Objects.equals(ucode, lion.getCode())) {
                            System.out.println("Enter hipo 's name: ");
                            name = keyboard.next();
                            System.out.println("Enter hipo 's code: ");
                            code = keyboard.next();
                            System.out.println("Enter hipo 's age: ");
                            age = keyboard.nextInt();
                            System.out.println("Enter hipo 's weight: ");
                            weight = keyboard.nextFloat();
                            System.out.println("Enter hipo 's class: ");
                            anclass = keyboard.next();
                            System.out.println("Enter hipo 's energy: ");
                            energy = keyboard.nextInt();
                            hipo h1 = new hipo(code, name, anclass, weight, age,energy);
                            Animal.AnimalArrayList.set(counter,h1);
                            h1.EnHipo();

                        }
                        counter++;


                    }
                }
                if(choice==3){
                    System.out.println("Enter the code of the animal you want to edit: ");
                    ucode = keyboard.next();
                    String code;
                    String anclass;
                    String name;
                    int age;
                    float weight;
                    int strength;
                    int counter=0;
                    for (Animal lion : Animal.AnimalArrayList) {
                        if (Objects.equals(ucode, lion.getCode())) {
                            System.out.println("Enter gorila 's name: ");
                            name = keyboard.next();
                            System.out.println("Enter gorila 's code: ");
                            code = keyboard.next();
                            System.out.println("Enter gorila 's age: ");
                            age = keyboard.nextInt();
                            System.out.println("Enter gorila 's weight: ");
                            weight = keyboard.nextFloat();
                            System.out.println("Enter gorila 's strength: ");
                            strength = keyboard.nextInt();
                            System.out.println("Enter animal 's class: ");
                            anclass = keyboard.next();
                            gorila g1 = new gorila(code, name, anclass, weight, age, strength);
                            Animal.AnimalArrayList.set(counter,g1);
                            g1.StrongGorila();



                        }
                        counter++;


                    }
                }


            }

            if (selection == 6) {
                String ucode;
                System.out.println("Enter code: ");
                ucode = keyboard.next();
                Animal.AnimalArrayList.removeIf(an -> Objects.equals(ucode, an.getCode()));

            }



            if (selection == 7) {
                flag = true;
            }




            Animal.serialize();

        }

    }


}


