public class gorila extends Animal {
    private int strength;

    public gorila(String code,String name,String anclass,float weight,int age,int strength) {
        super(code, name, anclass, weight, age);
        this.strength=strength;
    }


    public int getstrength() {
        return strength;
    }

    public void setstrength(int strength) {
        this.strength = strength;
    }

    public void StrongGorila(){
        if (strength>50){
            System.out.println("This is an strong gorila");
        }
        if (strength<=50) {
            System.out.println("This is a weak gorila");
        }
    }
}
